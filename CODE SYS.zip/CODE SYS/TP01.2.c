// main fonction
void main(void) {
  ANSELB = 0;       // Configure PORTB comme num�rique
  TRISB = 0;        // Configure PORTB en sortie
  LATB = 0x01;      // Commence avec la premi�re LED allum�e

  while(1) {
    // Balayage de gauche � droite
    char i;
    for (i = 0; i < 7; i++) {
      LATB = LATB << 1;  // D�cale la LED allum�e vers la droite
      Delay_ms(100);     // Pause pour l'effet
    }

    // Balayage de droite � gauche
    for (i = 0; i < 7; i++) {
      LATB = LATB >> 1;  // D�cale la LED allum�e vers la gauche
      Delay_ms(100);     // Pause pour l'effet
    }
  }
}
