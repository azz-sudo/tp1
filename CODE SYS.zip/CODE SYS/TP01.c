// Main function

void main(void) {
  ANSELB = 0;       // Sets all or PORTB as digital
  TRISB = 0;        // Set PORTB to be output
  LATB = 0;         // Turn OFF LEDs on PORTB
  while(1) {        // Endless loop
    LATB = ~LATB;   // Toggle LEDs on PORTB
    Delay_ms(1000); // Delay = 1000 ms
  }
}